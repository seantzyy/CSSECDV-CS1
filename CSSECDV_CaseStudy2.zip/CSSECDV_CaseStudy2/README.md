# CSSECDV_CS1


## Goal
As software security experts, our team has been hired by SECURITY Svcs to modify the program by implementing good security practices that we have observed are needed by the application.

## Documentation
https://docs.google.com/spreadsheets/d/1-o40DsaEPtEbukccAOi0mECgW7OhG1xZ_etvdqFRr-U/edit?usp=sharing

## Presentation
https://www.canva.com/design/DAFnLbu1Tvs/bD9YpegHfYwFf__E7g-EqA/edit?utm_content=DAFnLbu1Tvs&utm_campaign=designshare&utm_medium=link2&utm_source=sharebutton
